package com.example.smart_health_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
