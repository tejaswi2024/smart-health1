// signal_processing.dart
// Utilities for ECG signal processing: R-peak detection and heart rate computation

import 'dart:math';

class SignalProcessing {
  /// Detects R-peaks in the given ECG data.
  /// [ecgData] is a list of doubles representing the ECG signal.
  /// Returns a list of indices where R-peaks are detected.
  static List<int> detectRPeaks(List<double> ecgData) {
    if (ecgData.isEmpty) return [];

    // 1. Low-pass filter (simple IIR)
    final filtered = _lowPassFilter(ecgData, alpha: 0.2);

    // 2. Differentiate
    final diff = _differentiate(filtered);

    // 3. Square
    final squared = diff.map((v) => v * v).toList();

    // 4. Moving window integration
    final integrated = _movingWindowIntegration(squared, windowSize: 30);

    // 5. Thresholding
    final threshold = _findThreshold(integrated);
    final rPeaks = <int>[];
    for (int i = 1; i < integrated.length - 1; i++) {
      if (integrated[i] > threshold &&
          integrated[i] > integrated[i - 1] &&
          integrated[i] > integrated[i + 1]) {
        rPeaks.add(i);
        // Skip a refractory period (e.g., 200 ms at 250 Hz = 50 samples)
        i += 50;
      }
    }
    return rPeaks;
  }

  /// Computes heart rate (bpm) from R-peak indices and sampling frequency.
  static double computeHeartRate(List<int> rPeaks, double fs) {
    if (rPeaks.length < 2) return 0;
    final rrIntervals = <double>[];
    for (int i = 1; i < rPeaks.length; i++) {
      rrIntervals.add((rPeaks[i] - rPeaks[i - 1]) / fs);
    }
    final avgRR = rrIntervals.reduce((a, b) => a + b) / rrIntervals.length;
    return 60.0 / avgRR;
  }

  // --- Private helpers ---

  static List<double> _lowPassFilter(List<double> data, {double alpha = 0.2}) {
    final filtered = List<double>.filled(data.length, 0);
    filtered[0] = data[0];
    for (int i = 1; i < data.length; i++) {
      filtered[i] = alpha * filtered[i - 1] + (1 - alpha) * data[i];
    }
    return filtered;
  }

  static List<double> _differentiate(List<double> data) {
    final diff = List<double>.filled(data.length, 0);
    for (int i = 1; i < data.length; i++) {
      diff[i] = data[i] - data[i - 1];
    }
    return diff;
  }

  static List<double> _movingWindowIntegration(List<double> data, {int windowSize = 30}) {
    final integrated = List<double>.filled(data.length, 0);
    for (int i = 0; i < data.length; i++) {
      double sum = 0;
      int count = 0;
      for (int j = 0; j < windowSize; j++) {
        if (i - j >= 0) {
          sum += data[i - j];
          count++;
        }
      }
      integrated[i] = sum / (count == 0 ? 1 : count);
    }
    return integrated;
  }

  static double _findThreshold(List<double> data) {
    final mean = data.reduce((a, b) => a + b) / data.length;
    final std = sqrt(data.map((v) => pow(v - mean, 2)).reduce((a, b) => a + b) / data.length);
    return mean + 2 * std;
  }
} 