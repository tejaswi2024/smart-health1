import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smart_health_flutter/core/mqtt/mqtt_service.dart';
import 'package:mqtt_client/mqtt_client.dart';

class MqttManager with ChangeNotifier {
  MqttService? _mqttService;
  MqttService? get mqttService => _mqttService;

  bool _isConnected = false;
  bool get isConnected => _isConnected;

  String? _publishTopic;
  String? get publishTopic => _publishTopic;

  final List<String> _subscribedTopics = [];
  List<String> get subscribedTopics => _subscribedTopics;

  final StreamController<String> _messageStreamController = StreamController.broadcast();
  Stream<String> get messages => _messageStreamController.stream;

  Future<void> connect(String server, String clientIdentifier, int port, String publishTopic, {String? username, String? password}) async {
    _mqttService = MqttService(
      server: server,
      clientIdentifier: clientIdentifier,
      port: port,
      username: username,
      password: password,
    );
    await _mqttService!.connect();
    if (_mqttService!.client.connectionStatus!.state == MqttConnectionState.connected) {
      _isConnected = true;
      _publishTopic = publishTopic;
      _listenToMessages();
    } else {
      _isConnected = false;
      _publishTopic = null;
    }
    notifyListeners();
  }

  void _listenToMessages() {
    _mqttService!.updates!.listen((List<MqttReceivedMessage<MqttMessage>> c) {
      final MqttPublishMessage recMess = c[0].payload as MqttPublishMessage;
      final pt = MqttPublishPayload.bytesToStringAsString(recMess.payload.message);
      _messageStreamController.add(pt);
      print('MQTT_LOGS::- Received message: $pt from topic: ${c[0].topic}');
    });
  }

  void disconnect() {
    _mqttService?.disconnect();
    _isConnected = false;
    _publishTopic = null;
    _subscribedTopics.clear();
    notifyListeners();
  }

  void publish(String message) {
    if (_isConnected && _publishTopic != null) {
      _mqttService?.publish(_publishTopic!, message);
    }
  }

  void subscribe(String topic) {
    if (_isConnected && !_subscribedTopics.contains(topic)) {
      _mqttService?.subscribe(topic);
      _subscribedTopics.add(topic);
      notifyListeners();
    }
  }

  void unsubscribe(String topic) {
    if (_isConnected && _subscribedTopics.contains(topic)) {
      _mqttService?.unsubscribe(topic);
      _subscribedTopics.remove(topic);
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _messageStreamController.close();
    super.dispose();
  }
} 