import 'package:flutter_blue/flutter_blue.dart';

class BleDevice {
  final String id;
  final String name;
  final BluetoothDevice device;

  BleDevice({required this.id, required this.name, required this.device});
} 