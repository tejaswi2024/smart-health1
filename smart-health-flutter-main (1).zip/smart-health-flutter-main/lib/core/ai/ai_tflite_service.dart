import 'package:tflite_flutter/tflite_flutter.dart';
import 'dart:typed_data';

class AiTfliteService {
  Interpreter? _interpreter;
  static const String _modelPath = 'assets/models/Arrhythmia on_ECG_Classification.tflite';

  // Define class labels corresponding to the model's output
  static final List<String> classLabels = [
    'Normal',
    'Supraventricular',
    'Ventricular',
    'Fusion',
    'Noise',
  ];

  Future<void> loadModel() async {
    print('AI_MODEL_LOAD_DEBUG: Attempting to load model from: $_modelPath');
    try {
      _interpreter = await Interpreter.fromAsset(_modelPath);
      print('AI_MODEL_LOAD_DEBUG: Model loaded successfully: $_modelPath');

      // Log input and output tensor details for verification
      if (_interpreter != null) {
        print('AI_MODEL_LOAD_DEBUG: Input Tensors:');
        for (var i = 0; i < _interpreter!.getInputTensors().length; i++) {
          final tensor = _interpreter!.getInputTensors()[i];
          print('  Input Tensor $i: Name=${tensor.name}, Shape=${tensor.shape}, Type=${tensor.type}');
        }

        print('AI_MODEL_LOAD_DEBUG: Output Tensors:');
        for (var i = 0; i < _interpreter!.getOutputTensors().length; i++) {
          final tensor = _interpreter!.getOutputTensors()[i];
          print('  Output Tensor $i: Name=${tensor.name}, Shape=${tensor.shape}, Type=${tensor.type}');
        }
      }

    } catch (e) {
      print('AI_MODEL_LOAD_ERROR: Failed to load model: $e');
      print('AI_MODEL_LOAD_ERROR: StackTrace: ${StackTrace.current}');
    }
  }

  void dispose() {
    print('AI_MODEL_DISPOSE_DEBUG: Disposing AI model.');
    _interpreter?.close();
    _interpreter = null;
  }

  List<double> runInference(List<double> inputData) {
    if (_interpreter == null) {
      print('AI_INFERENCE_ERROR: Model not loaded. Please call loadModel() first.');
      return [];
    }

    try {
      final inputTensor = _interpreter!.getInputTensor(0);
      final outputTensor = _interpreter!.getOutputTensor(0);

      final inputShape = inputTensor.shape;
      final outputShape = outputTensor.shape;
      
      // Ensure the input data length matches the model's expected input size
      final expectedInputSize = inputShape.reduce((a, b) => a * b); // Flattened size
      if (inputData.length != expectedInputSize) {
        print('AI_INFERENCE_ERROR: Input data size mismatch. Expected $expectedInputSize, got ${inputData.length}');
        return [];
      }

      // Create a Float32List from the inputData and reshape it to the model's expected input shape
      final input = Float32List.fromList(inputData).reshape(inputShape);
      
      // Create an output buffer of the correct type and shape
      // The output shape is [1, 5], so it should be a List of List<double>
      var output = List.filled(outputShape[0], List<double>.filled(outputShape[1], 0.0));

      print('AI_INFERENCE_DEBUG: Running inference with input shape: ${inputShape} and output shape: ${outputShape}');
      _interpreter!.run(input, output);

      // The output is a List<List<double>>, so we take the first (and only) inner list
      final result = output[0]; // Access the actual prediction list
      print('AI_INFERENCE_DEBUG: Inference successful. Raw output: $result');
      return result;

    } catch (e) {
      print('AI_INFERENCE_ERROR: Error during inference: $e');
      print('AI_INFERENCE_ERROR: StackTrace: ${StackTrace.current}');
      return [];
    }
  }
} 