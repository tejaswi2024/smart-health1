import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import '../../core/models/ble_device.dart';

class BleService extends ChangeNotifier {
  final FlutterBlue _flutterBlue = FlutterBlue.instance;

  List<BleDevice> _scannedDevices = [];
  List<BleDevice> get scannedDevices => _scannedDevices;

  BluetoothDevice? _connectedDevice;
  BluetoothDevice? get connectedDevice => _connectedDevice;

  bool _isScanning = false;
  bool get isScanning => _isScanning;

  String? _connectionStatus;
  String? get connectionStatus => _connectionStatus;

  double? _latestHeartRate;
  double? get latestHeartRate => _latestHeartRate;
  set latestHeartRate(double? value) {
    _latestHeartRate = value;
    notifyListeners();
  }

  double? _latestRespiration;
  double? get latestRespiration => _latestRespiration;
  set latestRespiration(double? value) {
    _latestRespiration = value;
    notifyListeners();
  }

  // Add a stream for Bluetooth adapter state
  Stream<BluetoothState> get bluetoothState => _flutterBlue.state;

  // Start scanning for BLE devices
  void startScan() async {
    _scannedDevices = [];
    _isScanning = true;
    _connectionStatus = null;
    notifyListeners();

    // Debugging: Check Bluetooth adapter state
    BluetoothState state = await _flutterBlue.state.first;
    print('BLE_DEBUG: Bluetooth Adapter State: $state');
    print('BLE_DEBUG: Connected device at start of scan: ${_connectedDevice?.id.id}');

    if (state != BluetoothState.on) {
      _connectionStatus = 'Bluetooth is not ON. Please enable Bluetooth in your device settings.';
      _isScanning = false;
      notifyListeners();
      return; // Do not proceed with scan if Bluetooth is off
    }

    _flutterBlue.startScan(timeout: const Duration(seconds: 4)).then((_) {
      _isScanning = false;
      notifyListeners();
    });

    _flutterBlue.scanResults.listen((results) {
      for (ScanResult r in results) {
        print('BLE_DEBUG: Raw scanned device name: ${r.device.name}');
        if (!_scannedDevices.any((device) => device.id == r.device.id.id)) {
          _scannedDevices.add(BleDevice(
            id: r.device.id.id,
            name: r.device.name.trim().isNotEmpty ? r.device.name.trim() : 'Unknown Device',
            device: r.device,
          ));
          notifyListeners();
        }
      }
    });
  }

  // Stop scanning for BLE devices
  void stopScan() {
    _flutterBlue.stopScan();
    _isScanning = false;
    notifyListeners();
  }

  // Connect to a BLE device
  Future<bool> connectToDevice(BluetoothDevice device) async {
    _connectionStatus = 'Connecting...';
    notifyListeners();

    _flutterBlue.stopScan(); // Stop scanning before connecting

    try {
      await device.connect();
      _connectedDevice = device;
      _connectionStatus = 'Connected';
      print('BLE_DEBUG: Device connected: ${device.id.id}'); // Debug print
      notifyListeners();
      return true;
    } catch (e) {
      _connectionStatus = 'Connection Failed: $e';
      print('BLE_DEBUG: Connection failed: $e'); // Debug print
      notifyListeners();
      _connectedDevice = null;
      return false;
    }
  }

  // Disconnect from the current BLE device
  Future<void> disconnectDevice() async {
    if (_connectedDevice != null) {
      print('BLE_DEBUG: Disconnecting from: ${_connectedDevice!.id.id}'); // Debug print
      await _connectedDevice!.disconnect();
      _connectedDevice = null;
      _connectionStatus = 'Disconnected';
      notifyListeners();
    }
  }

  // Placeholder UUIDs - YOU MUST REPLACE THESE WITH YOUR DEVICE'S ACTUAL UUIDs
  // Example: static final Guid ECG_SERVICE_UUID = Guid('0000180D-0000-1000-8000-00805f9b34fb'); // Heart Rate Service UUID
  // Example: static final Guid ECG_CHARACTERISTIC_UUID = Guid('00002a37-0000-1000-8000-00805f9b34fb'); // Heart Rate Measurement Characteristic UUID
  static final Guid _ecgServiceUuid = Guid('0000180D-0000-1000-8000-00805f9b34fb'); // Placeholder
  static final Guid _ecgCharacteristicUuid = Guid('00002a37-0000-1000-8000-00805f9b34fb'); // Placeholder

  // Discover services and characteristics for a connected device
  Future<List<BluetoothService>> discoverServicesAndCharacteristics(BluetoothDevice device) async {
    _connectionStatus = 'Discovering services...';
    notifyListeners();
    try {
      List<BluetoothService> services = await device.discoverServices();
      _connectionStatus = 'Services discovered.';
      notifyListeners();
      return services;
    } catch (e) {
      _connectionStatus = 'Service discovery failed: $e';
      print('BLE_DEBUG: Service discovery failed: $e');
      notifyListeners();
      return [];
    }
  }

  // Subscribe to notifications from a specific characteristic
  Stream<List<int>>? subscribeToCharacteristic(BluetoothCharacteristic characteristic) {
    if (characteristic.properties.notify || characteristic.properties.indicate) {
      characteristic.setNotifyValue(true);
      return characteristic.value;
    } else {
      print('BLE_DEBUG: Characteristic does not support notify or indicate.');
      return null;
    }
  }

  // Helper to find the ECG characteristic
  BluetoothCharacteristic? getEcgCharacteristic(List<BluetoothService> services) {
    for (BluetoothService service in services) {
      if (service.uuid == _ecgServiceUuid) {
        for (BluetoothCharacteristic characteristic in service.characteristics) {
          if (characteristic.uuid == _ecgCharacteristicUuid) {
            return characteristic;
          }
        }
      }
    }
    return null;
  }

  @override
  void dispose() {
    _flutterBlue.stopScan();
    _connectedDevice?.disconnect();
    super.dispose();
  }
} 