import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'features/auth/login_screen.dart';
import 'features/patient_info/patient_info_screen.dart';
import 'features/device/device_scan_screen.dart';
import 'features/ecg/ecg_stream_screen.dart';
import 'features/auth/auth_service.dart';
import 'core/ble/ble_service.dart';
import 'core/ai/ai_tflite_service.dart';
import 'features/info/about_screen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'features/settings/settings_screen.dart';
import 'features/auth/register_screen.dart';
import 'features/patient_info/patient_info_service.dart';
import 'theme/theme_provider.dart';

class SmartHealthApp extends StatefulWidget {
  @override
  State<SmartHealthApp> createState() => _SmartHealthAppState();
}

class _SmartHealthAppState extends State<SmartHealthApp> {
  int _selectedIndex = 0;
  static List<Widget> _screens = <Widget>[
    HomeScreen(),
    DeviceScanScreen(),
    PatientInfoScreen(),
    SettingsScreen(),
    AboutScreen(),
  ];

  void _onItemTapped(int index) {
    final patientInfoService = Provider.of<PatientInfoService>(context, listen: false);

    if (!patientInfoService.hasInfo && (index == 0 || index == 1)) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Complete Your Profile'),
          content: const Text('Please fill in your personal details before accessing this feature.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => BleService()),
        Provider(create: (_) => AiTfliteService()..loadModel()),
      ],
      child: Consumer2<AuthService, ThemeProvider>(
        builder: (context, auth, themeProvider, _) {
          if (!auth.isLoggedIn) {
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Smart Health',
              theme: ThemeData(
                useMaterial3: true,
                colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF0066CC),
                  brightness: Brightness.light,
                ),
                textTheme: GoogleFonts.latoTextTheme(),
                cardTheme: CardThemeData(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                appBarTheme: const AppBarTheme(
                  backgroundColor: Color(0xFF0066CC),
                  foregroundColor: Colors.white,
                  elevation: 0,
                ),
              ),
              darkTheme: ThemeData(
                useMaterial3: true,
                colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF0066CC),
                  brightness: Brightness.dark,
                ),
                textTheme: GoogleFonts.latoTextTheme(ThemeData(brightness: Brightness.dark).textTheme),
                cardTheme: CardThemeData(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                appBarTheme: const AppBarTheme(
                  backgroundColor: Color(0xFF0066CC),
                  foregroundColor: Colors.white,
                  elevation: 0,
                ),
              ),
              themeMode: themeProvider.themeMode,
              home: const LoginScreen(),
              routes: {
                '/register': (context) => const RegisterScreen(),
              },
            );
          }
          // Main app after login
          return PostLoginWrapper(
            child: MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Smart Health',
              theme: ThemeData(
                useMaterial3: true,
                colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF0066CC),
                  brightness: Brightness.light,
                ),
                textTheme: GoogleFonts.latoTextTheme(),
                cardTheme: CardThemeData(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                appBarTheme: const AppBarTheme(
                  backgroundColor: Color(0xFF0066CC),
                  foregroundColor: Colors.white,
                  elevation: 0,
                ),
              ),
              darkTheme: ThemeData(
                useMaterial3: true,
                colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF0066CC),
                  brightness: Brightness.dark,
                ),
                textTheme: GoogleFonts.latoTextTheme(ThemeData(brightness: Brightness.dark).textTheme),
                cardTheme: CardThemeData(
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                appBarTheme: const AppBarTheme(
                  backgroundColor: Color(0xFF0066CC),
                  foregroundColor: Colors.white,
                  elevation: 0,
                ),
              ),
              themeMode: themeProvider.themeMode,
              home: Scaffold(
                appBar: AppBar(
                  title: Row(
                    children: [
                      Icon(Icons.favorite, color: Colors.redAccent),
                      const SizedBox(width: 8),
                      const Text('Smart Health'),
                    ],
                  ),
                  actions: [
                    PopupMenuButton<String>(
                      icon: const Icon(Icons.account_circle),
                      tooltip: 'Profile',
                      onSelected: (value) {
                        if (value == 'logout') {
                          Provider.of<AuthService>(context, listen: false).logout();
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            Navigator.of(context).popUntil((route) => route.isFirst);
                          });
                        }
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem<String>(
                          value: 'logout',
                          child: ListTile(
                            leading: Icon(Icons.logout, color: Colors.red),
                            title: Text('Logout'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                body: _screens[_selectedIndex],
                bottomNavigationBar: NavigationBar(
                  selectedIndex: _selectedIndex,
                  onDestinationSelected: _onItemTapped,
                  destinations: const [
                    NavigationDestination(icon: Icon(Icons.dashboard), label: 'Home'),
                    NavigationDestination(icon: Icon(Icons.bluetooth_searching), label: 'Connectivity'),
                    NavigationDestination(icon: Icon(Icons.person), label: 'Details'),
                    NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
                    NavigationDestination(icon: Icon(Icons.help_outline), label: 'Help'),
                  ],
                ),
              ),
              routes: {
                '/login': (context) => const LoginScreen(),
                '/patient_info': (context) => const PatientInfoScreen(),
                '/device_scan': (context) => const DeviceScanScreen(),
                '/settings': (context) => SettingsScreen(),
              },
            ),
          );
        },
      ),
    );
  }
}

class PostLoginWrapper extends StatefulWidget {
  final Widget child;
  const PostLoginWrapper({Key? key, required this.child}) : super(key: key);

  @override
  State<PostLoginWrapper> createState() => _PostLoginWrapperState();
}

class _PostLoginWrapperState extends State<PostLoginWrapper> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkPatientInfo());
  }

  void _checkPatientInfo() async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final patientInfoService = Provider.of<PatientInfoService>(context, listen: false);

    if (auth.username != null) {
      final info = await patientInfoService.loadInfo(auth.username!);
      if (info == null && mounted) {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PatientInfoScreen(isInitialSetup: true)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
  }

  void _showDeviceRequiredDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('No Device Connected'),
        content: const Text('Please connect to a Bluetooth device first.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showDetailsRequiredDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Complete Your Profile'),
        content: const Text('Please fill in your personal details before accessing this feature.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final username = Provider.of<AuthService>(context).username ?? 'User';
    final bleService = Provider.of<BleService>(context);
    final patientInfoService = Provider.of<PatientInfoService>(context);

    return Scaffold(
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                    child: Icon(Icons.account_circle, size: 40, color: theme.colorScheme.primary),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Welcome Back,', style: GoogleFonts.lato(fontSize: 18, color: theme.colorScheme.primary)),
                      Text(username, style: GoogleFonts.lato(fontSize: 24, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Row(
                children: [
                  Expanded(
                    child: DashboardCard(
                      title: 'Heart Rate',
                      icon: Icons.favorite,
                      value: bleService.latestHeartRate?.toStringAsFixed(0) ?? '--',
                      unit: 'BPM',
                      color: Colors.redAccent,
                      onTap: () {
                        if (!patientInfoService.hasInfo) {
                          _showDetailsRequiredDialog();
                        } else if (bleService.connectedDevice == null) {
                          _showDeviceRequiredDialog();
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ECGStreamScreen(initialMode: 'ecg')),
                          );
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: DashboardCard(
                      title: 'Respiration',
                      icon: Icons.cloud_queue,
                      value: bleService.latestRespiration?.toStringAsFixed(0) ?? '--',
                      unit: 'BPM',
                      color: Colors.blueAccent,
                      onTap: () {
                        if (!patientInfoService.hasInfo) {
                          _showDetailsRequiredDialog();
                        } else if (bleService.connectedDevice == null) {
                          _showDeviceRequiredDialog();
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ECGStreamScreen(initialMode: 'respiration')),
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureTile({required BuildContext context, required IconData icon, required String title, required VoidCallback onTap}) {
    return Card(
      elevation: 4.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, size: 50.0, color: Theme.of(context).primaryColor),
            const SizedBox(height: 10.0),
            Text(title, style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class DashboardCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String value;
  final String unit;
  final Color color;
  final VoidCallback onTap;

  const DashboardCard({
    Key? key,
    required this.title,
    required this.icon,
    required this.value,
    required this.unit,
    required this.color,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(icon, size: 36, color: color),
              const SizedBox(height: 12),
              Text(
                title,
                style: GoogleFonts.lato(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: theme.textTheme.bodyLarge!.color,
                ),
              ),
              const SizedBox(height: 4),
              RichText(
                text: TextSpan(
                  style: GoogleFonts.lato(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                  children: [
                    TextSpan(text: value),
                    TextSpan(
                      text: ' $unit',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Session History\n\n(Export and details coming soon)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 18, color: Colors.grey[700]),
      ),
    );
  }
} 