import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/db/database_helper.dart';

class AuthService extends ChangeNotifier {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  String? _currentUsername;
  bool _loggedIn = false;

  bool get isLoggedIn => _loggedIn;
  String? get username => _currentUsername;

  AuthService() {
    // In a real app, you'd load session from secure storage (e.g., a token)
    // For this prototype, we'll assume fresh login on restart.
  }

  Future<bool> register(String username, String password, {required String email, required String contact, required String name}) async {
    if (password.length < 8 || !RegExp(r'[A-Z]').hasMatch(password) || !RegExp(r'[a-z]').hasMatch(password)) {
      return false;
    }
    final db = await _dbHelper.database;
    try {
      await db.insert(
        'users',
        {'username': username, 'password': password, 'email': email, 'contact': contact, 'name': name},
        conflictAlgorithm: ConflictAlgorithm.abort,
      );
      _currentUsername = username;
      _loggedIn = true;
      notifyListeners();
      return true;
    } catch (e) {
      // Username might already exist due to UNIQUE constraint
      print('Registration failed: $e');
      return false;
    }
  }

  Future<bool> login(String username, String password) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> users = await db.query(
      'users',
      where: 'username = ? AND password = ?',
      whereArgs: [username, password],
    );

    if (users.isNotEmpty) {
      _currentUsername = username;
      _loggedIn = true;
      notifyListeners();
      return true;
    }
    _currentUsername = null;
    _loggedIn = false;
    notifyListeners();
    return false;
  }

  void logout() {
    _currentUsername = null;
    _loggedIn = false;
    notifyListeners();
  }
} 