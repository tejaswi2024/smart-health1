import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                      child: Icon(Icons.favorite, color: theme.colorScheme.primary, size: 40),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Smart Health Application v4.0',
                      style: GoogleFonts.robotoSlab(fontSize: 24, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'This application is designed to monitor ECG data from Bluetooth devices and utilize a TensorFlow Lite model for arrhythmia detection.',
                      style: GoogleFonts.roboto(fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Key Features',
                        style: GoogleFonts.robotoSlab(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _FeatureTile(icon: Icons.person, text: 'User Authentication & Patient Information Management'),
                        _FeatureTile(icon: Icons.bluetooth_searching, text: 'Bluetooth Low Energy (BLE) Device Scanning & Connection'),
                        _FeatureTile(icon: Icons.monitor_heart, text: 'Real-time ECG Data Visualization (Simulated & Real)'),
                        _FeatureTile(icon: Icons.science, text: 'On-device Arrhythmia Detection using TFLite AI Model'),
                      ],
                    ),
                  const SizedBox(height: 24),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Help & Troubleshooting',
                      style: GoogleFonts.robotoSlab(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _FeatureTile(icon: Icons.info, text: 'To use simulation mode, toggle the Simulation switch on the ECG screen.'),
                      _FeatureTile(icon: Icons.bluetooth, text: 'To connect to a real device, go to the Connectivity tab and scan for devices.'),
                      _FeatureTile(icon: Icons.monitor_heart, text: 'Tap Heart Rate or Respiration on the Home screen to view live or simulated data.'),
                      _FeatureTile(icon: Icons.download, text: 'Export your data from the Export tab or directly from the ECG screen.'),
                      _FeatureTile(icon: Icons.help, text: 'If you encounter issues, try restarting Bluetooth or toggling airplane mode.'),
                    ],
                  ),
                    const SizedBox(height: 24),
                    Text(
                      'Developed as part of a project for advanced health monitoring solutions.',
                      style: GoogleFonts.roboto(fontSize: 16, fontStyle: FontStyle.italic),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'For support or inquiries:',
                        style: GoogleFonts.robotoSlab(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Icon(Icons.email_outlined, color: theme.colorScheme.primary),
                        const SizedBox(width: 8),
                        SelectableText(
                          'support@smarthealth.com',
                          style: GoogleFonts.roboto(fontSize: 16, color: theme.colorScheme.primary),
                        ),
                      ],
                    ),
                  ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String text;
  const _FeatureTile({required this.icon, required this.text});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(icon, color: theme.colorScheme.primary, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.roboto(fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }
} 