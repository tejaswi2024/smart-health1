import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/db/database_helper.dart';
import 'package:flutter/foundation.dart';

class PatientInfo {
  final String username;
  final String zipCode;
  final int age;
  final String gender;
  final int height;
  final int weight;

  PatientInfo({
    required this.username,
    required this.zipCode,
    required this.age,
    required this.gender,
    required this.height,
    required this.weight,
  });

  Map<String, dynamic> toMap() {
    return {
      'username': username,
      'zipCode': zipCode,
      'age': age,
      'gender': gender,
      'height': height,
      'weight': weight,
    };
  }

  factory PatientInfo.fromMap(Map<String, dynamic> map) {
    return PatientInfo(
      username: map['username'],
      zipCode: map['zipCode'],
      age: map['age'],
      gender: map['gender'],
      height: map['height'],
      weight: map['weight'],
    );
  }
}

class PatientInfoService with ChangeNotifier {
  PatientInfo? _patientInfo;
  final DatabaseHelper _dbHelper = DatabaseHelper();

  PatientInfo? get patientInfo => _patientInfo;

  bool get hasInfo => _patientInfo != null;

  PatientInfoService() {
    // We will load info based on authenticated user, so removing loadInfo here
    // loadInfo();
  }

  Future<void> saveInfo(PatientInfo info) async {
    final db = await _dbHelper.database;
    
    // Check if there's existing data for this specific username
    List<Map<String, dynamic>> existing = await db.query(
      'patient_info',
      where: 'username = ?',
      whereArgs: [info.username],
    );

    if (existing.isNotEmpty) {
      await db.update(
        'patient_info',
        info.toMap(),
        where: 'username = ?',
        whereArgs: [info.username],
      );
    } else {
      await db.insert('patient_info', info.toMap());
    }
    _patientInfo = info;
    notifyListeners();
  }

  Future<PatientInfo?> loadInfo(String username) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'patient_info',
      where: 'username = ?',
      whereArgs: [username],
    );

    if (maps.isNotEmpty) {
      _patientInfo = PatientInfo.fromMap(maps.first);
      notifyListeners();
      return _patientInfo;
    }
    _patientInfo = null; // No info found for this user
    notifyListeners();
    return null;
  }
} 