import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'patient_info_service.dart';
import '../../features/auth/auth_service.dart';
import 'package:google_fonts/google_fonts.dart';

class PatientInfoScreen extends StatefulWidget {
  final bool isInitialSetup;
  const PatientInfoScreen({Key? key, this.isInitialSetup = false}) : super(key: key);

  @override
  State<PatientInfoScreen> createState() => _PatientInfoScreenState();
}

class _PatientInfoScreenState extends State<PatientInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _zipCodeController = TextEditingController();
  final _ageController = TextEditingController();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  String? _gender;
  String? _message;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadPatientInfo();
    });
  }

  @override
  void dispose() {
    _zipCodeController.dispose();
    _ageController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  Future<void> _loadPatientInfo() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    if (authService.username == null) {
      if (!widget.isInitialSetup) {
      setState(() {
        _message = 'Please log in to manage patient info.';
      });
      }
      return;
    }
    final service = Provider.of<PatientInfoService>(context, listen: false);
    final PatientInfo? loadedInfo = await service.loadInfo(authService.username!);

    if (loadedInfo != null) {
      setState(() {
        _zipCodeController.text = loadedInfo.zipCode;
        _ageController.text = loadedInfo.age.toString();
        _heightController.text = loadedInfo.height.toString();
        _weightController.text = loadedInfo.weight.toString();
        _gender = loadedInfo.gender;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);

    if (!authService.isLoggedIn || authService.username == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Patient Information', style: GoogleFonts.robotoSlab(fontWeight: FontWeight.bold)),
          centerTitle: true,
          elevation: 2,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
          ),
          leading: widget.isInitialSetup ? null : BackButton(),
          automaticallyImplyLeading: !widget.isInitialSetup,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_outline, size: 48, color: Colors.redAccent),
              const SizedBox(height: 16),
              Text(
                'Please log in to manage patient information.',
                textAlign: TextAlign.center,
                style: GoogleFonts.roboto(fontSize: 18, color: Colors.red),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                icon: const Icon(Icons.login),
                label: const Text('Go to Login'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/login');
                },
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Patient Information', style: GoogleFonts.robotoSlab(fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 2,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
        leading: widget.isInitialSetup ? null : BackButton(),
        automaticallyImplyLeading: !widget.isInitialSetup,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Patient Demographics',
                        style: GoogleFonts.robotoSlab(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 24),
                      TextFormField(
                        controller: _zipCodeController,
                        decoration: InputDecoration(
                          labelText: 'Zip Code *',
                          prefixIcon: const Icon(Icons.location_on_outlined),
                          filled: true,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        validator: (value) => value == null || value.isEmpty ? 'Zip Code is required' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _ageController,
                        decoration: InputDecoration(
                          labelText: 'Age',
                          prefixIcon: const Icon(Icons.cake_outlined),
                          filled: true,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Enter age';
                          final age = int.tryParse(value);
                          if (age == null || age < 0) return 'Enter valid age';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _heightController,
                        decoration: InputDecoration(
                          labelText: 'Height (cm)',
                          prefixIcon: const Icon(Icons.height),
                          filled: true,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Enter height';
                          final height = int.tryParse(value);
                          if (height == null || height < 0) return 'Enter valid height';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _weightController,
                        decoration: InputDecoration(
                          labelText: 'Weight (lb)',
                          prefixIcon: const Icon(Icons.monitor_weight_outlined),
                          filled: true,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Enter weight';
                          final weight = int.tryParse(value);
                          if (weight == null || weight < 0) return 'Enter valid weight';
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _gender,
                        decoration: InputDecoration(
                          labelText: 'Gender',
                          prefixIcon: const Icon(Icons.person_outline),
                          filled: true,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'Male', child: Text('Male')),
                          DropdownMenuItem(value: 'Female', child: Text('Female')),
                          DropdownMenuItem(value: 'Prefer not to say', child: Text('Prefer not to say')),
                        ],
                        onChanged: (value) => setState(() => _gender = value),
                        validator: (value) => value == null ? 'Select gender' : null,
                      ),
                      if (_message != null) ...[
                        const SizedBox(height: 12),
                        Text(_message!, style: GoogleFonts.roboto(color: Colors.green, fontWeight: FontWeight.w500)),
                      ],
                      const SizedBox(height: 28),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          icon: const Icon(Icons.save_alt_rounded),
                          label: Text(widget.isInitialSetup ? 'Save and Continue' : 'Save'),
                          style: FilledButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () async {
                            if (_formKey.currentState!.validate()) {
                              final service = Provider.of<PatientInfoService>(context, listen: false);
                              final authService = Provider.of<AuthService>(context, listen: false);
                              await service.saveInfo(PatientInfo(
                                username: authService.username!,
                                zipCode: _zipCodeController.text,
                                age: int.parse(_ageController.text),
                                gender: _gender!,
                                height: int.parse(_heightController.text),
                                weight: int.parse(_weightController.text),
                              ));
                              if (widget.isInitialSetup) {
                                Navigator.of(context).pop();
                              } else {
                              setState(() {
                                _message = 'Patient info saved!';
                              });
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Patient info saved successfully!'), backgroundColor: Colors.green),
                                );
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
} 