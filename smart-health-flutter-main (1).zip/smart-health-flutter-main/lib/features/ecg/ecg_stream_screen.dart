import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import 'package:flutter_blue/flutter_blue.dart';
import '../../core/ble/ble_service.dart';
import '../../core/ai/ai_tflite_service.dart';
import '../../core/utils/signal_processing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../export/export_service.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smart_health_flutter/core/mqtt/mqtt_manager.dart';
import 'dart:convert';

class ECGStreamScreen extends StatefulWidget {
  final BluetoothDevice? device;
  final String? initialMode; // 'ecg' or 'respiration'
  const ECGStreamScreen({Key? key, this.device, this.initialMode}) : super(key: key);

  @override
  State<ECGStreamScreen> createState() => _ECGStreamScreenState();
}

class _ECGStreamScreenState extends State<ECGStreamScreen> {
  final List<FlSpot> _spots = [];
  final StreamController<List<FlSpot>> _ecgDataController = StreamController<List<FlSpot>>.broadcast();
  double _xValue = 0.0;
  String _heartRate = '--';
  String _rhythmStatus = 'Monitoring...';
  String _arrhythmiaPrediction = 'No prediction yet';

  late BleService _bleService;
  late AiTfliteService _aiTfliteService;
  BluetoothCharacteristic? _ecgCharacteristic;
  StreamSubscription<List<int>>? _ecgDataSubscription;
  Timer? _simulationTimer; // Timer for simulation mode
  bool _isSimulationMode = false; // New state variable for simulation

  final List<double> _inferenceBuffer = []; // Buffer to collect single-channel data for AI inference
  static const int _inferenceBufferCapacity = 186; // Model expects 186 data points
  final List<double> _ecgBuffer = []; // Buffer for R-peak/HR computation
  static const int _ecgBufferCapacity = 250 * 5; // 5 seconds at 250Hz (adjust as needed)

  List<int> _lastRPeaks = [];
  final List<double> _hrBuffer = [];
  static const int _hrBufferLength = 8;

  final List<FlSpot> _respSpots = [];
  final StreamController<List<FlSpot>> _respDataController = StreamController<List<FlSpot>>.broadcast();
  double _respXValue = 0.0;
  bool _showRespiration = false;

  // Buffers for real BLE respiration extraction
  final List<double> _xAxisBuffer = [];
  final List<double> _yAxisBuffer = [];
  final List<double> _zAxisBuffer = [];
  static const int _respWindowSize = 600;

  // For export: store timestamps for each data point
  final List<List<dynamic>> _ecgExportWithTime = [];
  final List<List<dynamic>> _hrExportWithTime = [];
  final List<List<dynamic>> _respExportWithTime = [];
  double _startTime = 0.0;

  late bool _lockMode;

  @override
  void initState() {
    super.initState();
    _bleService = Provider.of<BleService>(context, listen: false);
    _aiTfliteService = Provider.of<AiTfliteService>(context, listen: false);
    if (widget.initialMode == 'respiration') {
      _showRespiration = true;
    }
    _lockMode = widget.initialMode != null;
    // Removed _initializeBleEcgStream() from initState, will be called conditionally
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Call _startStream only once when dependencies change after initial build
    // This prevents calling it multiple times on hot reload.
    if (_ecgCharacteristic == null && _simulationTimer == null) {
      _startStream();
    }
  }

  void _startStream() {
    _startTime = DateTime.now().millisecondsSinceEpoch / 1000.0;
    if (_isSimulationMode) {
      _startSimulationStream();
    } else {
      _initializeBleEcgStream();
    }
  }

  Future<void> _initializeBleEcgStream() async {
    print('BLE_ECG_DEBUG: Attempting to initialize BLE ECG stream.');
    try {
      List<BluetoothService> services = await _bleService.discoverServicesAndCharacteristics(widget.device!);
      _ecgCharacteristic = _bleService.getEcgCharacteristic(services);

      if (_ecgCharacteristic != null) {
        _ecgDataSubscription = _bleService.subscribeToCharacteristic(_ecgCharacteristic!)?.listen((value) {
          _parseEcgData(value);
        });
        print('BLE_ECG_DEBUG: Subscribed to ECG characteristic.');
      } else {
        print('BLE_ECG_DEBUG: ECG characteristic not found for device: ${widget.device!.name}. Cannot start BLE stream.');
        setState(() {
          _rhythmStatus = 'ECG Characteristic Not Found!';
        });
      }
    } catch (e) {
      print('BLE_ECG_DEBUG: Error initializing BLE ECG stream: $e');
      setState(() {
        _rhythmStatus = 'Error: $e';
      });
    }
  }

  void _startSimulationStream() {
    print('SIMULATION_DEBUG: Starting simulation stream.');
    int simulationCounter = 0;
    final Random random = Random();
    int currentMode = 0; // 0: Normal, 1: Arrhythmia, 2: Noise
    int modeChangeCounter = 0;
    const int modeDuration = 1000; // Samples before mode changes (e.g., 20 seconds at 50Hz)

    _simulationTimer = Timer.periodic(const Duration(milliseconds: 8), (timer) {
      const double sampleRate = 250.0; // More realistic sample rate
      final double time = simulationCounter / sampleRate;

      // Respiration simulation: low-frequency sine wave (e.g., 0.25 Hz = 15 breaths/min)
      final double respFreq = 0.25 + random.nextDouble() * 0.05; // 15-18 breaths/min
      final double respValue = 0.5 * sin(2 * pi * respFreq * time) + 0.5 + (random.nextDouble() - 0.5) * 0.02;
      _respSpots.add(FlSpot(_respXValue, (respValue * 100).clamp(0, 100)));
      _respXValue += 1.0;
      if (_respSpots.length > 100) {
        _respSpots.removeAt(0);
      }
      _respDataController.sink.add(List.from(_respSpots));

      // Change mode occasionally
      if (modeChangeCounter % modeDuration == 0) {
        currentMode = random.nextInt(3); // Randomly pick a mode: 0, 1, or 2
        print('SIMULATION_DEBUG: Changing mode to: $currentMode');
        modeChangeCounter = 1;
      } else {
        modeChangeCounter++;
      }

      double ecgValue = 0.0;
      double bpm = 72.0;
      double rr = 60.0 / bpm; // RR interval in seconds
      double tInCycle = time % rr;

      if (currentMode == 0) {
        // --- Realistic synthetic ECG: sum of Gaussians for P, QRS, T ---
        // P wave
        ecgValue += 0.15 *
            exp(-pow((tInCycle - 0.1 * rr) / (0.025 * rr), 2));
        // Q wave
        ecgValue -= 0.05 *
            exp(-pow((tInCycle - 0.2 * rr) / (0.016 * rr), 2));
        // R wave
        ecgValue += 1.0 *
            exp(-pow((tInCycle - 0.22 * rr) / (0.012 * rr), 2));
        // S wave
        ecgValue -= 0.15 *
            exp(-pow((tInCycle - 0.24 * rr) / (0.016 * rr), 2));
        // T wave
        ecgValue += 0.35 *
            exp(-pow((tInCycle - 0.35 * rr) / (0.04 * rr), 2));
        // Add mild baseline wander
        ecgValue += 0.03 * sin(2 * pi * time / 3.0);
        // Add mild noise
        ecgValue += (random.nextDouble() - 0.5) * 0.03;
      } else if (currentMode == 1) {
        // Arrhythmia: vary RR interval and add mild noise
        double arrBpm = 60.0 + random.nextDouble() * 40.0; // 60-100 bpm
        double arrRr = 60.0 / arrBpm;
        double arrTInCycle = time % arrRr;
        ecgValue += 0.15 * exp(-pow((arrTInCycle - 0.1 * arrRr) / (0.025 * arrRr), 2));
        ecgValue -= 0.05 * exp(-pow((arrTInCycle - 0.2 * arrRr) / (0.016 * arrRr), 2));
        ecgValue += 1.0 * exp(-pow((arrTInCycle - 0.22 * arrRr) / (0.012 * arrRr), 2));
        ecgValue -= 0.15 * exp(-pow((arrTInCycle - 0.24 * arrRr) / (0.016 * arrRr), 2));
        ecgValue += 0.35 * exp(-pow((arrTInCycle - 0.35 * arrRr) / (0.04 * arrRr), 2));
        ecgValue += 0.03 * sin(2 * pi * time / 3.0);
        ecgValue += (random.nextDouble() - 0.5) * 0.06;
        // Occasionally drop a beat
        if (random.nextDouble() < 0.01) ecgValue = 0.0;
      } else {
        // Noise: flatline with mild random noise
        ecgValue = (random.nextDouble() - 0.5) * 0.2;
      }

      // Scale to typical ECG mV range and convert to int for parser
      final double scaledEcgValue = (ecgValue * 1000).clamp(-2000, 2000);
      final double x = scaledEcgValue;
      final double y = scaledEcgValue * (0.98 + random.nextDouble() * 0.04);
      final double z = scaledEcgValue * (0.96 + random.nextDouble() * 0.08);

      List<int> simulatedRawData = List<int>.filled(103, 0);
      void addSignedInt16ToBytes(int value, int lsbIndex, int msbIndex) {
        int clampedValue = value.clamp(-32768, 32767);
        simulatedRawData[lsbIndex] = clampedValue & 0xFF;
        simulatedRawData[msbIndex] = (clampedValue >> 8) & 0xFF;
      }
      addSignedInt16ToBytes(x.toInt(), 97, 98);
      addSignedInt16ToBytes(y.toInt(), 99, 100);
      addSignedInt16ToBytes(z.toInt(), 101, 102);

      _parseEcgData(simulatedRawData);
      simulationCounter++;
    });
  }

  void _stopStreams() {
    print('STREAM_DEBUG: Stopping all data streams.');
    _simulationTimer?.cancel();
    _simulationTimer = null;
    _ecgDataSubscription?.cancel();
    _ecgCharacteristic?.setNotifyValue(false);
    _spots.clear(); // Clear spots when stopping
    _inferenceBuffer.clear(); // Clear inference buffer
    _xValue = 0.0;
    setState(() {
      _heartRate = '--';
      _rhythmStatus = 'Monitoring...';
      _arrhythmiaPrediction = 'No prediction yet';
    });
  }

  void _parseEcgData(List<int> rawData) {
    // Based on PlotterFragment.java, data seems to be 16-bit signed integers, little-endian.
    // There are 3 axes (X, Y, Z) and then other data.
    // We are interested in parsing the X, Y, Z values (indexes 97-102 in original dataString hex split)
    // The rawData is a list of bytes. The original Java code converts this to a hex string and then parses.
    // Let's directly parse bytes to signed 16-bit integers.

    // The original Java code used data from specific indices (97-102) of a hex string split by spaces.
    // This suggests that the rawData might have a specific structure where ECG data is located.
    // Assuming rawData contains the relevant bytes for X, Y, Z at specific offsets, similar to the Java logic.
    // In Java: `xAxis = strings[98] + strings[97];` corresponds to rawData bytes 97 and 98.
    // This means data[97] is LSB and data[98] is MSB for X-axis.

    if (rawData.length < 103) { // Ensure enough bytes for at least Z-axis (index 102)
      print('BLE_ECG_DEBUG: Raw data too short for 3-axis parsing.');
      return;
    }

    // ECG Data (X, Y, Z) parsing based on PlotterFragment.java
    // Original Java code converts byte array to hex string, then extracts bytes at specific string indices.
    // This is equivalent to direct byte access with awareness of byte order and two's complement.
    // X-axis: bytes at original string indices 97, 98 (LSB, MSB)
    // Y-axis: bytes at original string indices 99, 100 (LSB, MSB)
    // Z-axis: bytes at original string indices 101, 102 (LSB, MSB)
    // Given the `rawData` passed to this function is the raw byte array, we should directly access indices.
    // Assuming the `rawData` is the full packet, and the ECG data is at these offsets:

    // Function to convert 2 little-endian bytes to a signed 16-bit integer
    int bytesToSignedInt16(int byte1, int byte2) {
      int value = (byte2 << 8) | byte1; // byte1 is LSB, byte2 is MSB
      if ((value & 0x8000) != 0) { // Check if negative (16th bit is 1)
        value = value - 0x10000; // Convert to negative
      }
      return value;
    }

    // Extract X, Y, Z values
    final int rawX = bytesToSignedInt16(rawData[97], rawData[98]);
    final int rawY = bytesToSignedInt16(rawData[99], rawData[100]);
    final int rawZ = bytesToSignedInt16(rawData[101], rawData[102]);

    // For plotting, we'll use one of the axes (e.g., X-axis) or a derived value.
    final double y = (rawX + 2048) / 4096.0 * 120.0; // Example normalization from previous implementation

    _spots.add(FlSpot(_xValue, y.clamp(0, 120)));
    _xValue += 1.0;

    // Add single ECG value (y) to the inference buffer
    _inferenceBuffer.add(y);
    _ecgBuffer.add(y); // Add to buffer for R-peak/HR computation
    if (_ecgBuffer.length > _ecgBufferCapacity) {
      _ecgBuffer.removeAt(0);
    }

    // --- Respiration extraction from real BLE data ---
    // Buffer X, Y, Z axes (normalized to 0-100 for plotting)
    final double normX = (rawX + 2048) / 4096.0 * 100.0;
    final double normY = (rawY + 2048) / 4096.0 * 100.0;
    final double normZ = (rawZ + 2048) / 4096.0 * 100.0;
    _xAxisBuffer.add(normX);
    _yAxisBuffer.add(normY);
    _zAxisBuffer.add(normZ);
    if (_xAxisBuffer.length > _respWindowSize) _xAxisBuffer.removeAt(0);
    if (_yAxisBuffer.length > _respWindowSize) _yAxisBuffer.removeAt(0);
    if (_zAxisBuffer.length > _respWindowSize) _zAxisBuffer.removeAt(0);

    // Every window, select the axis with the highest average as the respiration channel
    if (_xAxisBuffer.length == _respWindowSize) {
      double avgX = _xAxisBuffer.reduce((a, b) => a + b) / _xAxisBuffer.length;
      double avgY = _yAxisBuffer.reduce((a, b) => a + b) / _yAxisBuffer.length;
      double avgZ = _zAxisBuffer.reduce((a, b) => a + b) / _zAxisBuffer.length;
      List<double> selectedResp;
      if (avgX >= avgY && avgX >= avgZ) {
        selectedResp = List<double>.from(_xAxisBuffer);
      } else if (avgY >= avgX && avgY >= avgZ) {
        selectedResp = List<double>.from(_yAxisBuffer);
      } else {
        selectedResp = List<double>.from(_zAxisBuffer);
      }
      // Plot the selected respiration channel
      _respSpots.clear();
      for (int i = 0; i < selectedResp.length; i++) {
        _respSpots.add(FlSpot(i.toDouble(), selectedResp[i].clamp(0, 100)));
        final double now = DateTime.now().millisecondsSinceEpoch / 1000.0 - _startTime;
        _respExportWithTime.add([
          now, // Use the same timestamp for this window
          _xAxisBuffer[i], _yAxisBuffer[i], _zAxisBuffer[i],
          0, 0, 0, // XY, YZ, ZX (not computed here)
          _xAxisBuffer[i], _yAxisBuffer[i], _zAxisBuffer[i],
          0, 0, 0, // filtered XY, YZ, ZX (not computed here)
        ]);
      }
      _respXValue = selectedResp.length.toDouble();
      _respDataController.sink.add(List.from(_respSpots));
      // Update BleService for Home screen (use mean of selectedResp as latest value)
      if (selectedResp.isNotEmpty) {
        final meanResp = selectedResp.reduce((a, b) => a + b) / selectedResp.length;
        _bleService.latestRespiration = meanResp;

        // Publish to MQTT
        final mqttManager = Provider.of<MqttManager>(context, listen: false);
        if (mqttManager.isConnected) {
          final data = {
            'type': 'respiration',
            'respiration_rate': meanResp,
            'timestamp': DateTime.now().toIso8601String(),
          };
          mqttManager.publish(jsonEncode(data));
        }
      }
    }

    // Run inference when buffer is full (186 data points)
    if (_inferenceBuffer.length >= _inferenceBufferCapacity) {
      _runInferenceOnEcgData();
      _inferenceBuffer.clear(); // Clear buffer after inference
    }

    // --- R-peak detection and heart rate computation ---
    // Only compute if we have enough data
    if (_ecgBuffer.length >= 250 * 3) { // At least 3 seconds of data
      final rPeaks = SignalProcessing.detectRPeaks(_ecgBuffer);
      final heartRate = SignalProcessing.computeHeartRate(rPeaks, 250); // 250Hz sample rate
      if (!heartRate.isNaN && heartRate >= 30 && heartRate <= 220) {
        _hrBuffer.add(heartRate);
        if (_hrBuffer.length > _hrBufferLength) {
          _hrBuffer.removeAt(0);
        }
        double avgHR = _hrBuffer.reduce((a, b) => a + b) / _hrBuffer.length;
        final double now = DateTime.now().millisecondsSinceEpoch / 1000.0 - _startTime;
        _hrExportWithTime.add([now, heartRate, avgHR]);
      }
      double displayHR = _hrBuffer.isNotEmpty
          ? _hrBuffer.reduce((a, b) => a + b) / _hrBuffer.length
          : 0;
      setState(() {
        _heartRate = displayHR == 0 ? '--' : displayHR.toStringAsFixed(0);
        _lastRPeaks = List<int>.from(rPeaks);
        // Update BleService for Home screen
        _bleService.latestHeartRate = displayHR == 0 ? null : displayHR;

        // Publish to MQTT
        final mqttManager = Provider.of<MqttManager>(context, listen: false);
        if (mqttManager.isConnected) {
          final data = {
            'type': 'ecg',
            'heart_rate': displayHR,
            'timestamp': DateTime.now().toIso8601String(),
          };
          mqttManager.publish(jsonEncode(data));
        }
      });
    }

    if (_spots.length > 100) {
      _spots.removeAt(0);
    }

    _ecgDataController.sink.add(List.from(_spots));

    // For improved ECG export: store timestamp and value
    final double now = DateTime.now().millisecondsSinceEpoch / 1000.0 - _startTime;
    _ecgExportWithTime.add([now, rawX.toDouble()]);
  }

  Future<void> _runInferenceOnEcgData() async {
    if (_inferenceBuffer.isEmpty) return;

    // The _inferenceBuffer now directly contains the 186 single-channel data points
    final List<double> inputForModel = List<double>.from(_inferenceBuffer);
    print('AI_INFERENCE_DEBUG: Input to model: $inputForModel'); // Debug print for model input

    try {
      // Ensure the input size matches the model's expectation
      final expectedInputSize = _inferenceBufferCapacity; // For a flattened 1D input of 186
      if (inputForModel.length != expectedInputSize) {
        print('AI_INFERENCE_ERROR: Input data size mismatch. Expected $expectedInputSize, got ${inputForModel.length}');
        setState(() {
          _arrhythmiaPrediction = 'Prediction Error: Input size mismatch';
          _rhythmStatus = 'Error in AI Prediction'; // Update rhythm status on error
        });
        return;
      }

      final results = _aiTfliteService.runInference(inputForModel);
      print('ECG_STREAM_DEBUG: Raw inference results received: $results'); // Debug print here
      if (results.isNotEmpty) {
        int maxIndex = 0;
        double maxValue = results[0];
        for (int i = 1; i < results.length; i++) {
          if (results[i] > maxValue) {
            maxValue = results[i];
            maxIndex = i;
          }
        }
        // This mapping needs to be specific to your model's output classes
        final List<String> classLabels = AiTfliteService.classLabels;
        if (maxIndex < classLabels.length) {
          setState(() {
            _arrhythmiaPrediction = 'Prediction: ${classLabels[maxIndex]} (Prob: ${(maxValue * 100).toStringAsFixed(2)}%)';
            _rhythmStatus = classLabels[maxIndex].contains('Normal')
                ? 'Normal Sinus Rhythm'
                : (classLabels[maxIndex].contains('Noise')
                    ? 'Noise Detected'
                    : '${classLabels[maxIndex]} Arrhythmia Detected');
          });
        } else {
          setState(() {
            _arrhythmiaPrediction = 'Prediction: Unknown Class (Index: $maxIndex)';
            _rhythmStatus = 'Unknown Rhythm'; // Set to unknown if class index is out of bounds
          });
        }
      } else {
        setState(() {
          _arrhythmiaPrediction = 'Prediction: No results';
          _rhythmStatus = 'Monitoring...'; // Reset rhythm status if no results
        });
      }
    } catch (e) {
      print('AI_INFERENCE_ERROR: $e');
      setState(() {
        _arrhythmiaPrediction = 'Prediction Error: $e';
        _rhythmStatus = 'Error in AI Prediction'; // Indicate error in UI
      });
    }
  }

  // Helper for summary stats
  List<List<dynamic>> _computeRespSummaryStats(int windowSec) {
    if (_respExportWithTime.isEmpty) return [];
    final List<List<dynamic>> summary = [];
    final double startTime = _respExportWithTime.first[0];
    final double endTime = _respExportWithTime.last[0];
    double windowStart = startTime;
    while (windowStart < endTime) {
      double windowEnd = windowStart + windowSec;
      final window = _respExportWithTime.where((row) => row[0] >= windowStart && row[0] < windowEnd).toList();
      if (window.isNotEmpty) {
        final values = window.map((row) => row[1] as num).toList();
        final mean = values.reduce((a, b) => a + b) / values.length;
        final min = values.reduce((a, b) => a < b ? a : b);
        final max = values.reduce((a, b) => a > b ? a : b);
        final std = values.length > 1
            ? sqrt(values.map((v) => (v - mean) * (v - mean)).reduce((a, b) => a + b) / (values.length - 1))
            : 0.0;
        summary.add([
          windowStart,
          windowEnd,
          mean,
          min,
          max,
          std,
        ]);
      }
      windowStart = windowEnd;
    }
    return summary;
  }

  Future<void> _exportData() async {
    int windowSec = 10;
    final selected = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) {
        // Only show relevant export options based on mode
        List<bool> values = _showRespiration ? [false, false, true] : [true, true, false];
        int dropdownValue = 10;
        return AlertDialog(
          title: const Text('Select Data to Export'),
          content: StatefulBuilder(
            builder: (context, setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (!_showRespiration) ...[
                  CheckboxListTile(
                    title: const Text('ECG Data'),
                    value: values[0],
                    onChanged: (v) => setState(() => values[0] = v ?? false),
                  ),
                  CheckboxListTile(
                    title: const Text('Heart Rate'),
                    value: values[1],
                    onChanged: (v) => setState(() => values[1] = v ?? false),
                  ),
                  ],
                  if (_showRespiration) ...[
                  CheckboxListTile(
                    title: const Text('Respiratory Data (Summary)'),
                    value: values[2],
                    onChanged: (v) => setState(() => values[2] = v ?? false),
                  ),
                  if (values[2])
                    Row(
                      children: [
                        const Text('Window size:'),
                        const SizedBox(width: 8),
                        DropdownButton<int>(
                          value: dropdownValue,
                          items: const [10, 30, 45, 60]
                              .map((v) => DropdownMenuItem(value: v, child: Text('$v seconds')))
                              .toList(),
                          onChanged: (v) => setState(() => dropdownValue = v ?? 10),
                        ),
                      ],
                    ),
                  ],
                ],
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, {
                'values': values,
                'windowSec': values[2] ? dropdownValue : 10,
              }),
              child: const Text('Export'),
            ),
          ],
        );
      },
    );
    if (selected == null) return;
    final values = selected['values'] as List<bool>;
    windowSec = selected['windowSec'] as int;
    final dir = await getTemporaryDirectory();
    final files = <XFile>[];
    if (!_showRespiration) {
    if (values[0]) {
      final ecgCsv = ExportService.generateEcgCsvWithTime(_ecgExportWithTime);
      final ecgFile = File('${dir.path}/ECGData.csv');
      await ecgFile.writeAsString(ecgCsv);
      files.add(XFile(ecgFile.path));
    }
    if (values[1]) {
      final hrCsv = ExportService.generateHeartRateCsvWithTime(_hrExportWithTime);
      final hrFile = File('${dir.path}/HeartRate.csv');
      await hrFile.writeAsString(hrCsv);
      files.add(XFile(hrFile.path));
    }
    }
    if (_showRespiration && values[2]) {
      final respSummary = _computeRespSummaryStats(windowSec);
      final respCsv = ExportService.generateRespiratorySummaryCsv(respSummary);
      final respFile = File('${dir.path}/RespiratoryData_Summary.csv');
      await respFile.writeAsString(respCsv);
      files.add(XFile(respFile.path));
    }
    if (files.isNotEmpty) {
      await Share.shareXFiles(files);
    }
  }

  @override
  void dispose() {
    _stopStreams(); // Ensure all streams are stopped on dispose
    _ecgDataController.close();
    _respDataController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Live Monitoring', style: GoogleFonts.robotoSlab(fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 2,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
        leading: BackButton(),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: () {},
            tooltip: 'Profile',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Quick Stats Row
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                      Row(
                        children: [
                              Expanded(
                                child: _StatPill(
                                  label: _showRespiration ? 'Resp. Rate' : 'Heart Rate',
                                  value: _showRespiration ? '16' : _heartRate,
                                  unit: _showRespiration ? 'BrPM' : 'BPM',
                                  color: _showRespiration ? Colors.green.shade600 : Colors.red.shade600,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: _StatPill(
                            label: 'Rhythm',
                            value: _rhythmStatus,
                            unit: '',
                            color: _rhythmStatus.contains('Normal')
                                ? Colors.green.shade600
                                : _rhythmStatus.contains('Noise')
                                    ? Colors.amber.shade700
                                    : Colors.red.shade700,
                          ),
                              ),
                            ],
                          ),
                          if (!_showRespiration) ...[
                            const SizedBox(height: 16),
                            _StatPill(
                              label: 'AI',
                              value: _arrhythmiaPrediction,
                              unit: '',
                              color: Colors.blue.shade700,
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 20),
                      // Mode & Simulation Controls
                      if (!_lockMode)
                      Row(
                        children: [
                          Expanded(
                            child: SegmentedButton<bool>(
                              segments: const [
                                ButtonSegment(value: false, label: Text('ECG')),
                                ButtonSegment(value: true, label: Text('Respiration')),
                              ],
                              selected: {_showRespiration},
                              onSelectionChanged: (s) {
                                setState(() => _showRespiration = s.first);
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Tooltip(
                            message: 'Toggle simulation mode for demo/testing',
                            child: Row(
                              children: [
                                Switch(
                                  value: _isSimulationMode,
                                  onChanged: (value) {
                                    setState(() {
                                      _isSimulationMode = value;
                                      _stopStreams();
                                      _startStream();
                                    });
                                  },
                                ),
                                const Text('Simulation'),
                              ],
                            ),
                          ),
                        ],
                      ),
                      if (_lockMode)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Tooltip(
                              message: 'Toggle simulation mode for demo/testing',
                              child: Row(
                                children: [
                                  Switch(
                                    value: _isSimulationMode,
                                    onChanged: (value) {
                                      setState(() {
                                        _isSimulationMode = value;
                                        _stopStreams();
                                        _startStream();
                                      });
                                    },
                                  ),
                                  const Text('Simulation'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      const SizedBox(height: 24),
                      // Chart Card
                      Card(
                        color: theme.colorScheme.surfaceVariant,
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _showRespiration ? 'Respiration Waveform' : 'ECG Waveform',
                                style: GoogleFonts.robotoSlab(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 12),
                              SizedBox(
                                height: 220,
                                child: _showRespiration
                                    ? StreamBuilder<List<FlSpot>>(
                                        stream: _respDataController.stream,
                                        builder: (context, snapshot) {
                                          if (!snapshot.hasData || snapshot.data!.isEmpty) {
                                            return const Center(child: Text('Waiting for Respiration data...'));
                                          }
                                          final spots = snapshot.data!;
                                          final minX = spots.isNotEmpty ? spots.first.x : 0.0;
                                          final maxX = spots.isNotEmpty ? spots.last.x : 100.0;
                                          return AspectRatio(
                                            aspectRatio: 1.70,
                                            child: LineChart(
                                              LineChartData(
                                                gridData: FlGridData(show: false),
                                                titlesData: FlTitlesData(show: true),
                                                borderData: FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
                                                minX: minX,
                                                maxX: maxX,
                                                minY: 0,
                                                maxY: 100,
                                                lineBarsData: [
                                                  LineChartBarData(
                                                    spots: spots,
                                                    isCurved: true,
                                                    color: Colors.green,
                                                    barWidth: 2,
                                                    isStrokeCapRound: true,
                                                    dotData: FlDotData(show: false),
                                                    belowBarData: BarAreaData(show: false),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      )
                                    : StreamBuilder<List<FlSpot>>(
                                        stream: _ecgDataController.stream,
                                        builder: (context, snapshot) {
                                          if (!snapshot.hasData || snapshot.data!.isEmpty) {
                                            return const Center(child: Text('Waiting for ECG data...'));
                                          }
                                          final spots = snapshot.data!;
                                          final minX = spots.isNotEmpty ? spots.first.x : 0.0;
                                          final maxX = spots.isNotEmpty ? spots.last.x : 100.0;
                                          final rPeakSpots = <FlSpot>[];
                                          for (final idx in _lastRPeaks) {
                                            if (idx >= 0 && idx < spots.length) {
                                              rPeakSpots.add(spots[idx]);
                                            }
                                          }
                                          return AspectRatio(
                                            aspectRatio: 1.70,
                                            child: LineChart(
                                              LineChartData(
                                                gridData: FlGridData(show: false),
                                                titlesData: FlTitlesData(show: true),
                                                borderData: FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
                                                minX: minX,
                                                maxX: maxX,
                                                minY: 0,
                                                maxY: 120,
                                                lineBarsData: [
                                                  LineChartBarData(
                                                    spots: spots,
                                                    isCurved: true,
                                                    color: Colors.red,
                                                    barWidth: 2,
                                                    isStrokeCapRound: true,
                                                    dotData: FlDotData(show: false),
                                                    belowBarData: BarAreaData(show: false),
                                                  ),
                                                  if (rPeakSpots.isNotEmpty)
                                                    LineChartBarData(
                                                      spots: rPeakSpots,
                                                      isCurved: false,
                                                      color: Colors.blue,
                                                      barWidth: 0,
                                                      isStrokeCapRound: false,
                                                      dotData: FlDotData(show: true),
                                                      belowBarData: BarAreaData(show: false),
                                                    ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Align(
                        alignment: Alignment.centerRight,
                        child: FilledButton.icon(
                          icon: const Icon(Icons.download),
                          label: const Text('Export Data'),
                          style: FilledButton.styleFrom(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                            textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 16),
                          ),
                          onPressed: _exportData,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- Stat Pill Widget ---
class _StatPill extends StatelessWidget {
  final String label;
  final String value;
  final String unit;
  final Color color;
  const _StatPill({required this.label, required this.value, required this.unit, required this.color});
  @override
  Widget build(BuildContext context) {
    final bool isRhythm = label == 'Rhythm';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: GoogleFonts.roboto(fontSize: 13, color: color.withOpacity(0.85), fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Flexible(
                child: SizedBox(
                  height: isRhythm ? 60 : 40,
                  child: Text(
                    value,
                    style: isRhythm
                        ? GoogleFonts.robotoSlab(fontSize: 16, color: color, fontWeight: FontWeight.bold)
                        : GoogleFonts.robotoSlab(fontSize: 20, color: color, fontWeight: FontWeight.bold),
                    maxLines: isRhythm ? 3 : 2,
                    overflow: TextOverflow.visible,
                    softWrap: true,
                  ),
                ),
              ),
              if (unit.isNotEmpty) ...[
                const SizedBox(width: 2),
                Text(unit, style: GoogleFonts.roboto(fontSize: 13, color: color.withOpacity(0.85), fontWeight: FontWeight.w500)),
              ],
            ],
          ),
        ],
      ),
    );
  }
} 