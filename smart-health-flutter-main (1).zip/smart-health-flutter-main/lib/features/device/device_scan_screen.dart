import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/ble/ble_service.dart';
import '../../core/models/ble_device.dart';
import '../ecg/ecg_stream_screen.dart';
import 'package:google_fonts/google_fonts.dart';

class DeviceScanScreen extends StatefulWidget {
  const DeviceScanScreen({Key? key}) : super(key: key);

  @override
  State<DeviceScanScreen> createState() => _DeviceScanScreenState();
}

class _DeviceScanScreenState extends State<DeviceScanScreen> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
            child: Consumer<BleService>(
              builder: (context, bleService, child) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Scan for Devices',
                      style: GoogleFonts.robotoSlab(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FilledButton.icon(
                          icon: const Icon(Icons.search),
                          label: const Text('Start Scan'),
                          style: FilledButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 15),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: bleService.isScanning ? null : () => bleService.startScan(),
                        ),
                        const SizedBox(width: 16),
                        FilledButton.icon(
                          icon: const Icon(Icons.stop_circle_outlined),
                          label: const Text('Stop Scan'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.redAccent,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 15),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: bleService.isScanning ? () => bleService.stopScan() : null,
                        ),
                      ],
                    ),
                    if (bleService.connectionStatus != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12.0),
                        child: Chip(
                          label: Text(
                            'Status: ${bleService.connectionStatus!}',
                            style: GoogleFonts.roboto(
                              color: bleService.connectionStatus!.contains('Failed') ? Colors.red : Colors.green,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          backgroundColor: bleService.connectionStatus!.contains('Failed')
                              ? Colors.red.withOpacity(0.1)
                              : Colors.green.withOpacity(0.1),
                        ),
                      ),
                    const SizedBox(height: 10),
                    Divider(height: 1, thickness: 1, color: Colors.grey.shade300),
                    const SizedBox(height: 10),
                    bleService.isScanning
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 24),
                            child: CircularProgressIndicator(),
                          )
                        : bleService.scannedDevices.isEmpty
                            ? Padding(
                                padding: const EdgeInsets.symmetric(vertical: 24),
                                child: Text('No devices found.', style: GoogleFonts.roboto(fontSize: 16)),
                              )
                            : ListView.separated(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: bleService.scannedDevices.length,
                                separatorBuilder: (context, idx) => const SizedBox(height: 10),
                                itemBuilder: (context, index) {
                                  final device = bleService.scannedDevices[index];
                                  bool isConnected = bleService.connectedDevice?.id == device.device.id;
                                  return Card(
                                    color: isConnected ? Colors.blue.withOpacity(0.08) : null,
                                    elevation: isConnected ? 2 : 0,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          ListTile(
                                            leading: Icon(
                                              isConnected ? Icons.bluetooth_connected : Icons.bluetooth,
                                              color: isConnected ? Colors.blue : Colors.grey,
                                              size: 32,
                                            ),
                                            title: Text(
                                              device.name == 'Unknown Device'
                                                  ? 'Unknown Device (ID: ${device.id})'
                                                  : device.name,
                                              style: GoogleFonts.robotoSlab(fontWeight: FontWeight.bold),
                                            ),
                                            subtitle: Text(device.id, style: GoogleFonts.roboto(fontSize: 13)),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(left: 72.0, right: 8.0, bottom: 8.0),
                                            child: Wrap(
                                              spacing: 8,
                                              runSpacing: 8,
                                              children: [
                                                if (isConnected) ...[
                                                  FilledButton.icon(
                                                    icon: const Icon(Icons.monitor_heart_outlined),
                                                    label: const Text('View ECG'),
                                                    style: FilledButton.styleFrom(
                                                      backgroundColor: Colors.green,
                                                      foregroundColor: Colors.white,
                                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                                      textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 14),
                                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                    ),
                                                    onPressed: () {
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) => ECGStreamScreen(device: device.device),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                  FilledButton.icon(
                                                    icon: const Icon(Icons.link_off),
                                                    label: const Text('Disconnect'),
                                                    style: FilledButton.styleFrom(
                                                      backgroundColor: Colors.red,
                                                      foregroundColor: Colors.white,
                                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                                      textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 14),
                                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                    ),
                                                    onPressed: () async {
                                                      await bleService.disconnectDevice();
                                                    },
                                                  ),
                                                ] else ...[
                                                  FilledButton.icon(
                                                    icon: const Icon(Icons.link),
                                                    label: const Text('Connect'),
                                                    style: FilledButton.styleFrom(
                                                      backgroundColor: Colors.blue,
                                                      foregroundColor: Colors.white,
                                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                                      textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600, fontSize: 14),
                                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                                    ),
                                                    onPressed: bleService.isScanning || bleService.connectedDevice != null
                                                        ? null
                                                        : () async {
                                                            bool success = await bleService.connectToDevice(device.device);
                                                            if (success) {
                                                              ScaffoldMessenger.of(context).showSnackBar(
                                                                SnackBar(content: Text('Connected to ${device.name}')),
                                                              );
                                                            } else {
                                                              ScaffoldMessenger.of(context).showSnackBar(
                                                                SnackBar(content: Text('Failed to connect to ${device.name}')),
                                                              );
                                                            }
                                                          },
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
} 