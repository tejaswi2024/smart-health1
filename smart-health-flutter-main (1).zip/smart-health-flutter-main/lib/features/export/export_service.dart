import 'package:csv/csv.dart';

class ExportService {
  /// ECGData.csv: One column, no header, each row is a single ECG value.
  static String generateEcgCsv(List<double> ecgData) {
    final rows = <List<dynamic>>[];
    for (final value in ecgData) {
      rows.add([value]);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// HeartRate.csv: Two columns, header: Real Time HR, Avg. HR
  static String generateHeartRateCsv(List<List<num>> heartRateData) {
    final rows = <List<dynamic>>[];
    rows.add(['Real Time HR', 'Avg. HR']);
    for (final pair in heartRateData) {
      rows.add([pair[0], pair[1]]);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// RespiratoryData.csv: 12 columns, header as in Java app
  static String generateRespiratoryCsv(List<List<num>> respData) {
    final rows = <List<dynamic>>[];
    rows.add([
      'normalizedX', 'normalizedY', 'normalizedZ', 'normalizedXY', 'normalizedYZ', 'normalizedZX',
      'filteredX', 'filteredY', 'filteredZ', 'filteredXY', 'filteredYZ', 'filteredZX',
    ]);
    for (final row in respData) {
      rows.add(row);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// ECGData.csv: Timestamp, Value
  static String generateEcgCsvWithTime(List<List<dynamic>> ecgData) {
    final rows = <List<dynamic>>[];
    rows.add(['Timestamp (s)', 'ECG Value']);
    for (final row in ecgData) {
      rows.add([row[0], row[1]]);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// HeartRate.csv: Timestamp, Real Time HR, Avg. HR
  static String generateHeartRateCsvWithTime(List<List<dynamic>> hrData) {
    final rows = <List<dynamic>>[];
    rows.add(['Timestamp (s)', 'Real Time HR', 'Avg. HR']);
    for (final row in hrData) {
      rows.add([row[0], row[1], row[2]]);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// RespiratoryData.csv: Timestamp, normalizedX, normalizedY, normalizedZ, ...
  static String generateRespiratoryCsvWithTime(List<List<dynamic>> respData) {
    final rows = <List<dynamic>>[];
    rows.add([
      'Timestamp (s)',
      'normalizedX', 'normalizedY', 'normalizedZ', 'normalizedXY', 'normalizedYZ', 'normalizedZX',
      'filteredX', 'filteredY', 'filteredZ', 'filteredXY', 'filteredYZ', 'filteredZX',
    ]);
    for (final row in respData) {
      rows.add(row);
    }
    return const ListToCsvConverter().convert(rows);
  }

  /// RespiratoryData_Summary.csv: Window Start, Window End, Mean, Min, Max, StdDev
  static String generateRespiratorySummaryCsv(List<List<dynamic>> summaryData) {
    final rows = <List<dynamic>>[];
    rows.add([
      'Window Start (s)', 'Window End (s)', 'Mean', 'Min', 'Max', 'StdDev',
    ]);
    for (final row in summaryData) {
      rows.add(row);
    }
    return const ListToCsvConverter().convert(rows);
  }
} 