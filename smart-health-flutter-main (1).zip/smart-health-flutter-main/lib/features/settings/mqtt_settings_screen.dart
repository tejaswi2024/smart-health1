import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smart_health_flutter/core/mqtt/mqtt_manager.dart';

class MqttSettingsScreen extends StatefulWidget {
  const MqttSettingsScreen({super.key});

  @override
  State<MqttSettingsScreen> createState() => _MqttSettingsScreenState();
}

class _MqttSettingsScreenState extends State<MqttSettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _hostController = TextEditingController();
  final _portController = TextEditingController();
  final _publishTopicController = TextEditingController();
  final _subscribeTopicController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Pre-fill fields if already connected
    final mqttManager = Provider.of<MqttManager>(context, listen: false);
    if (mqttManager.isConnected && mqttManager.mqttService != null) {
      _hostController.text = mqttManager.mqttService!.server;
      _portController.text = mqttManager.mqttService!.port.toString();
      _publishTopicController.text = mqttManager.publishTopic ?? '';
      _usernameController.text = mqttManager.mqttService!.username ?? '';
      // Password is not pre-filled for security
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MQTT Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _hostController,
                decoration: const InputDecoration(labelText: 'Host'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a host';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _portController,
                decoration: const InputDecoration(labelText: 'Port'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a port';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _publishTopicController,
                decoration: const InputDecoration(labelText: 'Publish Topic'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a topic to publish to';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _usernameController,
                decoration: const InputDecoration(labelText: 'Username (optional)'),
              ),
              TextFormField(
                controller: _passwordController,
                decoration: const InputDecoration(labelText: 'Password (optional)'),
                obscureText: true,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final mqttManager = Provider.of<MqttManager>(context, listen: false);
                    final host = _hostController.text;
                    final port = int.parse(_portController.text);
                    final topic = _publishTopicController.text;
                    final username = _usernameController.text;
                    final password = _passwordController.text;

                    // A unique client ID for each connection
                    final clientIdentifier = 'flutter_client_${DateTime.now().millisecondsSinceEpoch}';

                    mqttManager.connect(
                      host,
                      clientIdentifier,
                      port,
                      topic,
                      username: username.isNotEmpty ? username : null,
                      password: password.isNotEmpty ? password : null,
                    ).then((_) {
                      if (mqttManager.isConnected) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Connected to MQTT broker')),
                        );
                        Navigator.of(context).pop();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Failed to connect to MQTT broker')),
                        );
                      }
                    });
                  }
                },
                child: const Text('Save and Connect'),
              ),
              const SizedBox(height: 10),
              Consumer<MqttManager>(
                builder: (context, mqttManager, child) {
                  if (!mqttManager.isConnected) return const SizedBox.shrink();
                  return Card(
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text('Subscriptions', style: Theme.of(context).textTheme.titleLarge),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  controller: _subscribeTopicController,
                                  decoration: const InputDecoration(labelText: 'Subscribe to Topic'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              ElevatedButton(
                                onPressed: () {
                                  if (_subscribeTopicController.text.isNotEmpty) {
                                    mqttManager.subscribe(_subscribeTopicController.text);
                                    _subscribeTopicController.clear();
                                  }
                                },
                                child: const Text('Subscribe'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ...mqttManager.subscribedTopics.map((topic) => ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(topic),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => mqttManager.unsubscribe(topic),
                            ),
                          )),
                          if (mqttManager.subscribedTopics.isNotEmpty) ... [
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MqttMessagesScreen())),
                              child: const Text('View Messages'),
                            ),
                          ]
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MqttMessagesScreen extends StatefulWidget {
  const MqttMessagesScreen({Key? key}) : super(key: key);

  @override
  State<MqttMessagesScreen> createState() => _MqttMessagesScreenState();
}

class _MqttMessagesScreenState extends State<MqttMessagesScreen> {
  final List<String> _messages = [];
  StreamSubscription? _subscription;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final mqttManager = Provider.of<MqttManager>(context, listen: false);
    _subscription ??= mqttManager.messages.listen((message) {
      setState(() {
        _messages.insert(0, message);
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Received Messages')),
      body: _messages.isEmpty
          ? const Center(child: Text('Awaiting messages...'))
          : ListView.builder(
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text(message),
                  ),
                );
              },
            ),
    );
  }
} 