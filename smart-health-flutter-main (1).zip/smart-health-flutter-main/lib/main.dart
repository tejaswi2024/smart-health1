import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'features/auth/auth_service.dart';
import 'features/patient_info/patient_info_service.dart';
import 'core/ble/ble_service.dart';
import 'core/db/database_helper.dart';
import 'core/mqtt/mqtt_manager.dart';
import 'theme/theme_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => PatientInfoService()),
        ChangeNotifierProvider(create: (_) => BleService()),
        ChangeNotifierProvider(create: (_) => MqttManager()),
        Provider(create: (_) => DatabaseHelper()),
      ],
      child: SmartHealthApp(),
    ),
    );
}
